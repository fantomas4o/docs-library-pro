<?php
$upload_dir = wp_upload_dir();
$base_dir = $upload_dir['basedir'];
$base_url = $upload_dir['baseurl'];

// ДОБАВЕНИ: PDF, DOC, DOCX, XLS, XLSX, RTF
$allowed_extensions = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'rtf'];
$all_files = [];

if (is_dir($base_dir)) {
    try {
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($base_dir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($iterator as $file) {
            $ext = strtolower($file->getExtension());
            if ($file->isFile() && in_array($ext, $allowed_extensions)) {
                $all_files[] = $file->getPathname();
            }
        }
    } catch (Exception $e) {
        $pattern = $base_dir . '/**/*.' . implode(' ' . $base_dir . '/**/*.', $allowed_extensions);
        $all_files = glob($pattern, GLOB_BRACE) ?: [];
    }
}

$docs = [];

// SVG ИКОНКИ ПО ФОРМАТ
$icon_map = [
    'pdf'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6z"/><polyline points="14 2 14 8 20 8"/><path d="M9 15h2v2H9z"/><path d="M13 15h2v2h-2z"/><path d="M9 18h6"/></svg>',
    'doc'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6z"/><polyline points="14 2 14 8 20 8"/><path d="M9 13h6"/><path d="M9 17h6"/></svg>',
    'docx' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6z"/><polyline points="14 2 14 8 20 8"/><path d="M9 13h6"/><path d="M9 17h6"/></svg>',
    'xls'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6z"/><polyline points="14 2 14 8 20 8"/><path d="M9 11h2v2H9z"/><path d="M13 11h2v6h-2z"/><path d="M9 15h2v2H9z"/></svg>',
    'xlsx' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6z"/><polyline points="14 2 14 8 20 8"/><path d="M9 11h2v2H9z"/><path d="M13 11h2v6h-2z"/><path d="M9 15h2v2H9z"/></svg>',
    'rtf'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6z"/><polyline points="14 2 14 8 20 8"/><path d="M9 13h2v4H9z"/><path d="M13 13h2v4h-2z"/><path d="M9 15h6"/></svg>'
];

foreach ($all_files as $file) {
    $filename = basename($file);
    $relative_path = str_replace($base_dir . '/', '', $file);
    $file_url = $base_url . '/' . $relative_path;
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

    $attachment_id = attachment_url_to_postid($file_url);
    $attachment = $attachment_id ? get_post($attachment_id) : null;

    $title = $attachment ? get_the_title($attachment) : '';
    $description = $attachment ? trim($attachment->post_excerpt) : '';

    if (empty($title)) {
        $title = ucfirst(str_replace(['_', '-'], ' ', pathinfo($filename, PATHINFO_FILENAME)));
        $title = preg_replace('/\b(fedya|CODE|UIC|pdf|\.pdf|\d{4,})\b/i', '', $title);
        $title = trim(preg_replace('/\s+/', ' ', $title));
        if (empty($title)) $title = $filename;
    }

    $file_size = file_exists($file) ? size_format(filesize($file), 2) : '';
    $icon = $icon_map[$ext] ?? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6z"/><polyline points="14 2 14 8 20 8"/></svg>';

    $keywords = mb_strtolower($title . ' ' . $description . ' ' . $filename, 'UTF-8');
    $docs[] = [
        'title' => $title,
        'desc' => $description,
        'url' => $file_url,
        'size' => $file_size,
        'icon' => $icon,
        'keywords' => $keywords,
        'ext' => $ext
    ];
}

usort($docs, fn($a, $b) => strcasecmp($a['title'], $b['title']));
$total_docs = count($docs);
?>

<div id="finalDocs">
  <section style="background:linear-gradient(135deg,#f5f7fa 0%,#c3cfe2 100%);padding:50px 0;">
    <div style="max-width:1200px;margin:0 auto;padding:0 20px;">
      <h2 style="text-align:center;font-size:2.5rem;margin-bottom:15px;color:#003366;font-weight:700;text-shadow:2px 2px 4px rgba(0,0,0,0.1);">
        Документи и стандарти
      </h2>
      <p style="text-align:center;max-width:850px;margin:0 auto 40px;color:#444;font-size:1.1rem;line-height:1.7;">
        В тази секция са събрани основни нормативни документи, технически указания и стандарти, 
        свързани със спирачните системи, безопасността и поддръжката на железопътния транспорт.
      </p>

      <div style="max-width:650px;margin:0 auto 30px;position:relative;">
        <input type="text" id="finalSearch" onkeyup="filterFinalDocs()" 
               placeholder="Търсене по заглавие, описание или файл..."
               style="width:100%;padding:16px 50px 16px 20px;border:2px solid #0073e6;border-radius:50px;font-size:1rem;box-sizing:border-box;box-shadow:0 4px 12px rgba(0,115,230,0.15);transition:all 0.3s;">
        <span style="position:absolute;right:20px;top:50%;transform:translateY(-50%);color:#0073e6;font-size:1.3rem;pointer-events:none;"></span>
      </div>

      <div id="resultsCounter" style="text-align:center;margin-bottom:25px;font-size:1rem;color:#555;font-weight:500;">
        Показани: <strong id="visibleCount"><?php echo $total_docs; ?></strong> от <strong><?php echo $total_docs; ?></strong> документа
      </div>

      <div id="finalGrid" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:30px;">
        <?php if (empty($docs)): ?>
          <p style="text-align:center;color:#999;grid-column:1/-1;padding:60px 20px;font-size:1.2rem;">Няма качени документи.</p>
        <?php else: ?>
          <?php foreach ($docs as $doc): 
            // ЦВЯТ ПО ФОРМАТ
            $color = match($doc['ext']) {
                'pdf' => '#e53e3e',
                'doc', 'docx' => '#3182ce',
                'xls', 'xlsx' => '#2f855a',
                'rtf' => '#9c27b0', // ЛИЛАВ ЗА RTF
                default => '#718096'
            };
          ?>
            <div class="final-item" data-keywords="<?php echo esc_attr($doc['keywords']); ?>"
                 style="background:#fff;border-radius:16px;padding:30px 25px;box-shadow:0 5px 20px rgba(0,0,0,0.08);text-align:center;transition:all .3s;border:2px solid transparent;overflow:hidden;position:relative;">
              
              <div style="width:60px;height:60px;margin:0 auto 20px;color:<?php echo $color; ?>;animation:float 3s ease-in-out infinite;">
                <?php echo $doc['icon']; ?>
              </div>
              
              <h3 style="margin:10px 0;color:#003366;font-size:1.2rem;font-weight:600;min-height:60px;display:flex;align-items:center;justify-content:center;">
                <?php echo esc_html($doc['title']); ?>
              </h3>
              
              <p style="font-size:0.95rem;color:#666;margin:12px 0 20px;min-height:50px;line-height:1.6;">
                <?php echo $doc['desc'] ? esc_html($doc['desc']) : '<span style="color:#ccc;font-style:italic;">Няма описание</span>'; ?>
              </p>
              
              <?php if (!empty($doc['size'])): ?>
                <div style="font-size:0.85rem;color:#888;margin-bottom:18px;">
                  Размер: <strong><?php echo esc_html($doc['size']); ?></strong>
                </div>
              <?php endif; ?>
              
              <a href="<?php echo esc_url($doc['url']); ?>" target="_blank" rel="noopener noreferrer"
                 style="display:inline-block;background:linear-gradient(135deg,<?php echo $color; ?> 0%,<?php echo adjustBrightness($color, -30); ?> 100%);color:white;padding:12px 32px;border-radius:50px;text-decoration:none;font-weight:600;font-size:0.95rem;box-shadow:0 4px 12px rgba(0,0,0,0.15);transition:all .3s;position:relative;overflow:hidden;"
                 onmouseover="this.style.transform='translateY(-3px)';this.style.boxShadow='0 8px 20px rgba(0,0,0,0.2)'"
                 onmouseout="this.style.transform='translateY(0)';this.style.boxShadow='0 4px 12px rgba(0,0,0,0.15)'">
                Изтегли <?php echo strtoupper($doc['ext']); ?>
                <span style="position:absolute;top:0;left:0;width:100%;height:100%;background:linear-gradient(90deg,transparent,rgba(255,255,255,0.2),transparent);transform:translateX(-100%);transition:0.6s;"></span>
              </a>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>

      <div id="noResults" style="display:none;text-align:center;padding:60px 20px;">
        <div style="width:80px;height:80px;margin:0 auto 20px;background:#e2e8f0;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:40px;color:#718096;"></div>
        <h3 style="color:#666;font-size:1.5rem;margin-bottom:10px;">Няма намерени резултати</h3>
        <p style="color:#999;">Опитайте с други ключови думи</p>
      </div>
    </div>
  </section>
</div>

<?php
function adjustBrightness($hex, $steps) {
    $hex = ltrim($hex, '#');
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    $r = max(0, min(255, $r + $steps));
    $g = max(0, min(255, $g + $steps));
    $b = max(0, min(255, $b + $steps));
    return sprintf("#%02x%02x%02x", $r, $g, $b);
}
?>

<style>
@keyframes float {
  0%,100%{transform:translateY(0)}
  50%{transform:translateY(-12px)}
}
#finalSearch:focus{outline:none;border-color:#005bb5;box-shadow:0 6px 20px rgba(0,115,230,0.25)}
.final-item:hover{transform:translateY(-8px);box-shadow:0 15px 35px rgba(0,115,230,0.18);border-color:<?php echo $color; ?>;}
.final-item svg{width:100%;height:100%;stroke:currentColor;}
.final-item a span{animation:shine 1.5s infinite;}
@keyframes shine{0%{transform:translateX(-100%)}100%{transform:translateX(100%)}}
@media(max-width:768px){#finalGrid{grid-template-columns:1fr;gap:20px}h2{font-size:2rem!important}}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const totalDocs = <?php echo $total_docs; ?>;
  const counter = document.getElementById('resultsCounter');
  const normalize = str => str.normalize('NFD').replace(/[\u0300-\u036f]/g, '');

  window.filterFinalDocs = function() {
    const q = normalize((document.getElementById('finalSearch')?.value || '').toLowerCase().trim());
    const items = document.querySelectorAll('.final-item');
    const grid = document.getElementById('finalGrid');
    const noResults = document.getElementById('noResults');
    let visibleCount = 0;

    items.forEach(item => {
      const text = normalize((item.dataset.keywords || '').toLowerCase());
      const match = text.includes(q);
      item.style.display = match ? 'block' : 'none';
      if (match) visibleCount++;
    });

    if (visibleCount === 0 && q !== '') {
      noResults.style.display = 'block';
      grid.style.display = 'none';
    } else {
      noResults.style.display = 'none';
      grid.style.display = 'grid';
    }

    if (visibleCount === totalDocs && q === '') counter.style.display = 'none';
    else {
      counter.style.display = 'block';
      document.getElementById('visibleCount').textContent = visibleCount;
    }
  };
});
</script>