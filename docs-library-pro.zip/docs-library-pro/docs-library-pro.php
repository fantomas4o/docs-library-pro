<?php
/**
 * Plugin Name: Docs Library Pro
 * Plugin URI:  https://urocibg.eu/
 * Description: A Beautiful, Fast & Smart Document Library for WordPress. Automatically from uploads.
 * Version:     1.0.3
 * Author:      Fedya Serafiev
 * Author URI:  https://urocibg.eu/
 * License:     GPL v2 or later
 * Text Domain: docs-library-pro
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) exit;

define('DOCS_LIBRARY_PRO_VERSION', '1.0.0');
define('DOCS_LIBRARY_PRO_PATH', plugin_dir_path(__FILE__));
define('DOCS_LIBRARY_PRO_URL', plugin_dir_url(__FILE__));

class Docs_Library_Pro {
    public function __construct() {
        add_action('init', [$this, 'init']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('enqueue_block_assets', [$this, 'enqueue_block_assets']);
    }

    public function init() {
        add_shortcode('docs_library', [$this, 'render_shortcode']);
        load_plugin_textdomain('docs-library-pro', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }

    public function enqueue_assets() {
        if (!is_admin() && $this->should_load_assets()) {
            wp_enqueue_style('docs-library-pro', DOCS_LIBRARY_PRO_URL . 'assets/style.css', [], DOCS_LIBRARY_PRO_VERSION);
        }
    }

    public function enqueue_block_assets() {
        if (has_block('docs-library-pro/docs-library')) {
            wp_enqueue_style('docs-library-pro-block', DOCS_LIBRARY_PRO_URL . 'blocks/docs-library-block/style.css', [], DOCS_LIBRARY_PRO_VERSION);
        }
    }

    private function should_load_assets() {
        global $post;
        if (!$post) return false;
        return has_shortcode($post->post_content, 'docs_library') || has_block('docs-library-pro/docs-library', $post);
    }

    public function render_shortcode($atts) {
        $atts = shortcode_atts(['formats' => 'pdf,docx,doc,rtf,txt,xls,xlsx,ppt,pptx'], $atts, 'docs_library');
        $allowed = array_map('trim', explode(',', $atts['formats']));
        ob_start();
        include DOCS_LIBRARY_PRO_PATH . 'includes/render.php';
        return ob_get_clean();
    }
}

new Docs_Library_Pro();

// Gutenberg Block
add_action('init', function() {
    if (!function_exists('register_block_type')) return;

    register_block_type(DOCS_LIBRARY_PRO_PATH . 'blocks/docs-library-block', [
        'render_callback' => function($attributes) {
            $formats = $attributes['formats'] ?? 'pdf,docx,doc,rtf,txt,xls,xlsx,ppt,pptx';
            return do_shortcode('[docs_library formats="' . esc_attr($formats) . '"]');
        }
    ]);
});