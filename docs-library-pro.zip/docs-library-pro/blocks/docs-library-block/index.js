import { registerBlockType } from '@wordpress/blocks';
import { TextControl } from '@wordpress/components';
import { __ } from '@wordpress/i18n';

registerBlockType('docs-library-pro/docs-library', {
    title: __('Docs Library', 'docs-library-pro'),
    icon: 'media-document',
    category: 'widgets',
    attributes: {
        formats: {
            type: 'string',
            default: 'pdf,docx,doc,rtf,txt,xls,xlsx,ppt,pptx'
        }
    },
    edit: ({ attributes, setAttributes }) => {
        return (
            <TextControl
                label={__('Allowed Formats', 'docs-library-pro')}
                value={attributes.formats}
                onChange={(value) => setAttributes({ formats: value })}
                help={__('Comma-separated: pdf,docx,txt', 'docs-library-pro')}
            />
        );
    },
    save: () => null
});